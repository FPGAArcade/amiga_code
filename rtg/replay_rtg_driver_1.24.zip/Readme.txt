Installation
===============================


Copy the file Replay.card to libs:Picasso96/


ChangeLog
==============================
1.24:
        - Fix fast mem alloc with 060db
        - Request MMU cache mode change (040/060)

1023:
	- Various fixes on the interrupt
	- Removed blinking LED
