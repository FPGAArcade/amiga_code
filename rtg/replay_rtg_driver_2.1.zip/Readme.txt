Installation
===============================


Copy the file Replay.card to libs:Picasso96/


ChangeLog
==============================
2.1:
        - Show a warning (RECOVERY_ALERT) if unable to set MMU page flags
        - Fix MMU page range calculation

2.0:
        - Allow Replay.card to be embedded inside replay.rom

1.26:
        - Support 24bit TrueColor
	
1.25:
        - Use mmu.library to set MMU cache mode (if available)

1.24:
        - Fix fast mem alloc with 060db
        - Request MMU cache mode change (040/060)

1023:
	- Various fixes on the interrupt
	- Removed blinking LED
